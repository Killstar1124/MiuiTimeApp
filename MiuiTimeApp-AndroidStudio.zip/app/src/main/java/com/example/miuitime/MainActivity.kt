package com.example.miuitime

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessAlarm
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private val Page = Color(0xFFF4E9E3)
private val CardBlue = Color(0xFFCBD5E2)
private val CardSelected = Color(0xFF8795AA)
private val Ink = Color(0xFF62636A)
private val Accent = Color(0xFFE9455A)
private val SoftPink = Color(0xFFF4CFD0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TimeApp(this) }
    }
}

private enum class Tab { TIME, TOOLS, SETTINGS }
private enum class Tool { ALARM, STOPWATCH, COUNTDOWN }

@Composable
fun TimeApp(context: Context) {
    var tab by remember { mutableStateOf(Tab.TIME) }
    var tool by remember { mutableStateOf(Tool.STOPWATCH) }
    var selectedSource by remember { mutableStateOf("北京时间（阿里）") }
    var running by remember { mutableStateOf(true) }
    var showMillis by remember { mutableStateOf(true) }
    var use24 by remember { mutableStateOf(true) }
    var autoCalibrate by remember { mutableStateOf(true) }
    var offsetMs by remember { mutableLongStateOf(0L) }
    var latencyMs by remember { mutableLongStateOf(0L) }
    var syncStatus by remember { mutableStateOf("等待校准") }
    var refreshKey by remember { mutableIntStateOf(0) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(running, refreshKey, offsetMs) {
        while (running) {
            now = System.currentTimeMillis() + offsetMs
            delay(if (showMillis) 40 else 250)
        }
    }
    LaunchedEffect(autoCalibrate, refreshKey) {
        if (autoCalibrate) {
            while (true) {
                calibrateTime(
                    onResult = { offset, latency, status ->
                        offsetMs = offset; latencyMs = latency; syncStatus = status
                    }
                )
                delay(60_000)
            }
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Accent, background = Page, surface = Page,
            onBackground = Ink, onSurface = Ink, secondary = CardSelected
        )
    ) {
        Box(Modifier.fillMaxSize().background(Page)) {
            Column(Modifier.fillMaxSize()) {
                when (tab) {
                    Tab.TIME -> TimePage(
                        now, selectedSource, running, showMillis, use24, offsetMs, latencyMs,
                        syncStatus, onSource = { selectedSource = it },
                        onToggle = { running = !running },
                        onSync = {
                            refreshKey++
                            syncStatus = "正在校准…"
                        }
                    )
                    Tab.TOOLS -> ToolsPage(context, tool, { tool = it })
                    Tab.SETTINGS -> SettingsPage(
                        showMillis, use24, autoCalibrate,
                        { showMillis = it }, { use24 = it }, { autoCalibrate = it }
                    )
                }
            }
            NavigationBar(
                modifier = Modifier.align(Alignment.BottomCenter),
                containerColor = SoftPink,
                tonalElevation = 0.dp
            ) {
                NavigationBarItem(
                    selected = tab == Tab.TIME,
                    onClick = { tab = Tab.TIME },
                    icon = { Icon(Icons.Default.AccessTime, null) },
                    label = { Text("时间") },
                    colors = navColors()
                )
                NavigationBarItem(
                    selected = tab == Tab.TOOLS,
                    onClick = { tab = Tab.TOOLS },
                    icon = { Icon(Icons.Default.AccessAlarm, null) },
                    label = { Text("工具") },
                    colors = navColors()
                )
                NavigationBarItem(
                    selected = tab == Tab.SETTINGS,
                    onClick = { tab = Tab.SETTINGS },
                    icon = { Icon(Icons.Default.Settings, null) },
                    label = { Text("设置") },
                    colors = navColors()
                )
            }
        }
    }
}

@Composable
private fun navColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = Ink, selectedTextColor = Ink,
    indicatorColor = Color(0xFFF9E5DF), unselectedIconColor = Ink,
    unselectedTextColor = Ink
)

@Composable
private fun TimePage(
    now: Long, selected: String, running: Boolean, showMillis: Boolean, use24: Boolean,
    offset: Long, latency: Long, status: String,
    onSource: (String) -> Unit, onToggle: () -> Unit, onSync: () -> Unit
) {
    val sources = listOf("系统", "北京时间（阿里）", "淘宝", "京东", "拼多多", "云闪付", "中信银行", "中国银行", "东京时间", "伦敦时间", "纽约时间")
    Column(
        Modifier.fillMaxSize().padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 100.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("时间", Modifier.fillMaxWidth(), fontSize = 34.sp, fontWeight = FontWeight.Medium, color = Color(0xFF88817E))
        Spacer(Modifier.height(32.dp))
        Text(selected, fontSize = 22.sp, fontWeight = FontWeight.Medium, color = Ink)
        Spacer(Modifier.height(24.dp))
        Text(
            formatTime(now, showMillis, use24, selected),
            fontSize = if (showMillis) 42.sp else 48.sp,
            fontWeight = FontWeight.Medium, color = Ink,
            textAlign = TextAlign.Center, maxLines = 1, softWrap = false
        )
        Spacer(Modifier.height(30.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxWidth().height(((sources.size + 1) / 2 * 118).dp),
            horizontalArrangement = Arrangement.spacedBy(18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            userScrollEnabled = false
        ) {
            items(sources) { source ->
                val selectedColor by animateColorAsState(if (source == selected) CardSelected else CardBlue, label = "sourceColor")
                Box(
                    Modifier.fillMaxWidth().height(86.dp).clip(RoundedCornerShape(28.dp))
                        .background(selectedColor).clickable { onSource(source) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(source, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = Color(0xFF555A64), textAlign = TextAlign.Center)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Text("时差 ${offset}ms    网络延迟 ${latency}ms", fontSize = 13.sp, color = Color(0xFF8A8583))
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Default.Refresh, null, modifier = Modifier.size(20.dp).clickable { onSync() }, tint = Ink)
        }
        Text(status, fontSize = 12.sp, color = Color(0xFF8A8583))
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = onToggle, shape = CircleShape,
            colors = ButtonDefaults.buttonColors(containerColor = Accent),
            contentPadding = PaddingValues(0.dp), modifier = Modifier.size(64.dp)
        ) {
            Icon(if (running) Icons.Default.Stop else Icons.Default.PlayArrow, null, modifier = Modifier.size(34.dp), tint = Color.White)
        }
    }
}

private fun formatTime(millis: Long, showMillis: Boolean, use24: Boolean, source: String): String {
    val zone = when (source) {
        "东京时间" -> "Asia/Tokyo"
        "伦敦时间" -> "Europe/London"
        "纽约时间" -> "America/New_York"
        "系统" -> TimeZone.getDefault().id
        else -> "Asia/Shanghai"
    }
    val pattern = (if (use24) "HH:mm:ss" else "hh:mm:ss a") + if (showMillis) ".SSS" else ""
    return SimpleDateFormat(pattern, Locale.getDefault()).apply { timeZone = TimeZone.getTimeZone(zone) }.format(Date(millis))
}

private suspend fun calibrateTime(onResult: (Long, Long, String) -> Unit) {
    withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        try {
            val connection = URL("https://www.baidu.com/").openConnection()
            connection.connectTimeout = 3500
            connection.readTimeout = 3500
            connection.getInputStream().use { it.read() }
            val end = System.currentTimeMillis()
            val serverDate = connection.getHeaderFieldDate("Date", -1L)
            if (serverDate > 0) {
                val latency = end - start
                val estimatedServerTime = serverDate + latency / 2
                onResult(estimatedServerTime - end, latency, "校准成功 · HTTP Date")
            } else {
                onResult(0, end - start, "已连接，服务器未返回时间")
            }
            connection.disconnect()
        } catch (_: Exception) {
            onResult(0, 0, "网络校准失败，显示设备时间")
        }
    }
}

@Composable
private fun ToolsPage(context: Context, tool: Tool, onTool: (Tool) -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 20.dp).padding(top = 22.dp, bottom = 100.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("时间工具", fontSize = 32.sp, color = Color(0xFF88817E), fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tool.values().forEach {
                FilterChip(selected = tool == it, onClick = { onTool(it) }, label = { Text(when (it) { Tool.ALARM -> "闹钟"; Tool.STOPWATCH -> "秒表"; Tool.COUNTDOWN -> "倒计时" }) })
            }
        }
        Spacer(Modifier.height(16.dp))
        when (tool) {
            Tool.ALARM -> AlarmTool(context)
            Tool.STOPWATCH -> StopwatchTool()
            Tool.COUNTDOWN -> CountdownTool()
        }
    }
}

@Composable
private fun AlarmTool(context: Context) {
    var hour by remember { mutableStateOf("07") }
    var minute by remember { mutableStateOf("00") }
    var title by remember { mutableStateOf("时间提醒") }
    var message by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(CardBlue).padding(20.dp)) {
        Text("设置闹钟", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(hour, { hour = it.filter(Char::isDigit).take(2) }, label = { Text("小时 0-23") }, modifier = Modifier.weight(1f), singleLine = true)
            Text(":", fontSize = 26.sp)
            OutlinedTextField(minute, { minute = it.filter(Char::isDigit).take(2) }, label = { Text("分钟 0-59") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        OutlinedTextField(title, { title = it }, label = { Text("提醒名称") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Button(onClick = {
            val h = hour.toIntOrNull()
            val m = minute.toIntOrNull()
            if (h == null || m == null || h !in 0..23 || m !in 0..59) {
                message = "请输入有效的小时和分钟"
            } else {
                val calendar = java.util.Calendar.getInstance().apply {
                    set(java.util.Calendar.HOUR_OF_DAY, h); set(java.util.Calendar.MINUTE, m)
                    set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
                    if (timeInMillis <= System.currentTimeMillis()) add(java.util.Calendar.DAY_OF_YEAR, 1)
                }
                val intent = Intent(context, AlarmReceiver::class.java).putExtra("title", title.ifBlank { "时间提醒" })
                val pending = PendingIntent.getBroadcast(context, 1207, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                try {
                    if (android.os.Build.VERSION.SDK_INT >= 31 && !alarmManager.canScheduleExactAlarms()) {
                        context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
                        message = "请在系统页面允许精确闹钟后，再次设置"
                    } else {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pending)
                        message = "已设置：${String.format("%02d:%02d", h, m)}"
                    }
                } catch (_: Exception) { message = "设置失败，请检查系统闹钟权限" }
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("设置闹钟") }
        if (message.isNotBlank()) Text(message, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
private fun StopwatchTool() {
    var running by remember { mutableStateOf(false) }
    var elapsed by remember { mutableLongStateOf(0L) }
    var startedAt by remember { mutableLongStateOf(0L) }
    LaunchedEffect(running) {
        while (running) {
            elapsed = System.currentTimeMillis() - startedAt
            delay(30)
        }
    }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(CardBlue).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("秒表", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(20.dp))
        Text(formatDuration(elapsed), fontSize = 36.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = {
                if (!running) { startedAt = System.currentTimeMillis() - elapsed; running = true } else running = false
            }) { Text(if (running) "暂停" else if (elapsed > 0) "继续" else "开始") }
            OutlinedButton(onClick = { running = false; elapsed = 0L }) { Icon(Icons.Default.RestartAlt, null); Text("重置") }
        }
    }
}

@Composable
private fun CountdownTool() {
    var minutes by remember { mutableStateOf("5") }
    var remaining by remember { mutableLongStateOf(0L) }
    var running by remember { mutableStateOf(false) }
    var endAt by remember { mutableLongStateOf(0L) }
    LaunchedEffect(running) {
        while (running) {
            remaining = (endAt - System.currentTimeMillis()).coerceAtLeast(0L)
            if (remaining == 0L) running = false
            delay(100)
        }
    }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(CardBlue).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("倒计时", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(minutes, { minutes = it.filter(Char::isDigit).take(4) }, label = { Text("分钟") }, singleLine = true)
        Spacer(Modifier.height(18.dp))
        Text(formatDuration(remaining), fontSize = 36.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = {
                if (running) running = false
                else {
                    if (remaining <= 0L) remaining = (minutes.toLongOrNull() ?: 5L).coerceAtLeast(1L) * 60_000L
                    endAt = System.currentTimeMillis() + remaining
                    running = true
                }
            }) { Text(if (running) "暂停" else if (remaining > 0) "继续" else "开始") }
            OutlinedButton(onClick = { running = false; remaining = 0L }) { Text("重置") }
        }
    }
}

private fun formatDuration(ms: Long): String {
    val total = ms.coerceAtLeast(0L)
    val h = total / 3_600_000
    val m = (total / 60_000) % 60
    val s = (total / 1000) % 60
    val milli = (total % 1000) / 10
    return String.format(Locale.getDefault(), "%02d:%02d:%02d.%02d", h, m, s, milli)
}

@Composable
private fun SettingsPage(
    showMillis: Boolean, use24: Boolean, autoCalibrate: Boolean,
    onMillis: (Boolean) -> Unit, on24: (Boolean) -> Unit, onAuto: (Boolean) -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 20.dp).padding(top = 22.dp, bottom = 100.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("设置", fontSize = 32.sp, color = Color(0xFF88817E), fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(20.dp))
        Column(Modifier.clip(RoundedCornerShape(28.dp)).background(CardBlue).padding(horizontal = 18.dp)) {
            SettingRow("显示毫秒", "主时钟显示到毫秒", showMillis, onMillis)
            HorizontalDivider(color = Color.White.copy(alpha = .6f))
            SettingRow("24 小时制", "关闭后使用 12 小时制", use24, on24)
            HorizontalDivider(color = Color.White.copy(alpha = .6f))
            SettingRow("自动校准", "每分钟尝试校准网络时间", autoCalibrate, onAuto)
        }
        Spacer(Modifier.height(18.dp))
        Text("关于", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text("时间 · MIUIX 风格概念实现", fontSize = 15.sp)
        Text("版本 1.0.0", fontSize = 13.sp, color = Color(0xFF8A8583))
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, fontSize = 13.sp, color = Color(0xFF777D87))
        }
        Switch(checked, onChange)
    }
}
